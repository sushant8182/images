package com.example.imagesearch

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
